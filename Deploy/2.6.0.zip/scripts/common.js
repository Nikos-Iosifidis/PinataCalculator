var localStorageDataName = "pinata_extension";
var localStorageOrdersName = "pinata_extension_orders";
var localStorageShopId = "pinata_extension_shopId";